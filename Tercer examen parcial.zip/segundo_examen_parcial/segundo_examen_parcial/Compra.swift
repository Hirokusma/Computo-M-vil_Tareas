//
//  Compra.swift
//  segundo_examen_parcial
//
//  Created by Macbook on 4/29/19.
//  Copyright © 2019 FI. All rights reserved.
//

import UIKit

class CompraController: UIViewController {
    
    var precio:Double!
    
    @IBOutlet weak var preciolab: UILabel!
    override func viewDidLoad() {
        
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        preciolab.text = String(precio)
    }
    
}
